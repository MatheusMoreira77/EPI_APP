package com.example.epi_app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Cadastro_Colaborador : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = Db.get(this)


        if (!db.ehAdmin(Sessao.usuario)) {
            startActivity(Intent(this, Login::class.java))
            finish()
            return
        }

        enableEdgeToEdge()
        setContentView(R.layout.activity_cadastro_colaborador)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val etNome = findViewById<EditText>(R.id.editTextText)
        val etSenha = findViewById<EditText>(R.id.editTextText2)
        val etFuncao = findViewById<EditText>(R.id.editTextText3)

        // CADASTRAR
        findViewById<Button>(R.id.button6).setOnClickListener {
            val nome = etNome.text.toString().trim()
            val senha = etSenha.text.toString()
            val funcao = etFuncao.text.toString().trim()

            when {
                nome.isEmpty() || senha.isEmpty() || funcao.isEmpty() -> {
                    Toast.makeText(this, "Preencha nome, senha e função.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                senha.length < 4 -> {
                    Toast.makeText(this, "A senha precisa ter pelo menos 4 caracteres.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            }

            val resultado = try {
                db.cadastrarColaborador(nome, senha, funcao)
            } catch (e: Exception) {
                Toast.makeText(this, "Erro ao salvar: ${e.message}", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            when (resultado) {
                ResultadoCadastro.OK -> {
                    Toast.makeText(this, "Colaborador \"$nome\" cadastrado!", Toast.LENGTH_LONG).show()
                    startActivity(Intent(this, Menu_Admin::class.java))
                    finish()
                }
                ResultadoCadastro.JA_EXISTE ->
                    Toast.makeText(this, "Já existe um colaborador com o nome \"$nome\".", Toast.LENGTH_LONG).show()
                ResultadoCadastro.ERRO ->
                    Toast.makeText(this, "Não foi possível cadastrar. Tente novamente.", Toast.LENGTH_LONG).show()
            }
        }

        // MENU (volta sem salvar)
        findViewById<Button>(R.id.button7).setOnClickListener {
            startActivity(Intent(this, Menu_Admin::class.java))
            finish()
        }
    }
}