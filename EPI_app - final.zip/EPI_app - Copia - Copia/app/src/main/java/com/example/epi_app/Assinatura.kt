package com.example.epi_app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import java.io.ByteArrayOutputStream

class SignatureView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val caminho = Path()
    private val pincel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 6f
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private var ultimoX = 0f
    private var ultimoY = 0f
    private var vazia = true

    fun estaVazia() = vazia

    fun limpar() {
        caminho.reset()
        vazia = true
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.WHITE)
        canvas.drawPath(caminho, pincel)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                // impede que o dialog/scroll roube o gesto enquanto assina
                parent?.requestDisallowInterceptTouchEvent(true)
                caminho.moveTo(x, y)
                ultimoX = x
                ultimoY = y
            }
            MotionEvent.ACTION_MOVE -> {
                caminho.quadTo(ultimoX, ultimoY, (x + ultimoX) / 2, (y + ultimoY) / 2)
                ultimoX = x
                ultimoY = y
                vazia = false
            }
            MotionEvent.ACTION_UP -> performClick()
        }
        invalidate()
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun toPng(): ByteArray {
        val original = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        draw(Canvas(original))

        // reduz para no máximo 500px de largura: arquivo pequeno no banco
        val largura = minOf(original.width, 500)
        val altura = (original.height * (largura.toFloat() / original.width)).toInt().coerceAtLeast(1)
        val final = Bitmap.createScaledBitmap(original, largura, altura, true)

        val saida = ByteArrayOutputStream()
        final.compress(Bitmap.CompressFormat.PNG, 100, saida)
        return saida.toByteArray()
    }
}
