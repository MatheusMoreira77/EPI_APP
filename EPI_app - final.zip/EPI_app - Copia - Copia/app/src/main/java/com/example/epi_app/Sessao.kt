package com.example.epi_app

object Sessao {
    var usuario: String = ""
}
