package com.example.epi_app

data class Retirada(
    val id: Int,
    val usuario: String,
    val equipamento: String,
    val tamanho: String,
    val dataHora: String,
    val assinatura: ByteArray? = null
)