package com.example.epi_app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ResultadoCadastro { OK, JA_EXISTE, ERRO }


class Db private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "epi.db", null, 3) {

    companion object {
        const val BOTA = "Bota de segurança"
        const val CAPACETE = "Capacete de segurança"
        const val LUVA = "Luva de proteção"
        const val OCULOS = "Óculos de proteção"
        const val PROTETOR = "Protetor auricular"

        const val PERFIL_ADMIN = "admin"
        const val PERFIL_COLABORADOR = "colaborador"

        @Volatile
        private var instancia: Db? = null

        fun get(context: Context): Db =
            instancia ?: synchronized(this) {
                instancia ?: Db(context).also { instancia = it }
            }

        private fun novoSalt(): String {
            val bytes = ByteArray(16)
            SecureRandom().nextBytes(bytes)
            return bytes.joinToString("") { "%02x".format(it) }
        }

        private fun hash(senha: String, salt: String): String {
            val digest = MessageDigest.getInstance("SHA-256").digest((salt + senha).toByteArray())
            return digest.joinToString("") { "%02x".format(it) }
        }
    }

    private fun garantirUsuario(
        db: SQLiteDatabase,
        usuario: String,
        senha: String,
        funcao: String,
        perfil: String
    ) {
        val salt = novoSalt()
        db.insertWithOnConflict(
            "usuarios",
            null,
            ContentValues().apply {
                put("usuario", usuario)
                put("salt", salt)
                put("senha_hash", hash(senha, salt))
                put("funcao", funcao)
                put("perfil", perfil)
            },
            SQLiteDatabase.CONFLICT_IGNORE
        )
    }

    private fun garantirUsuariosPadrao(db: SQLiteDatabase) {
        garantirUsuario(db, "davi", "1234", "Colaborador", PERFIL_COLABORADOR)
        garantirUsuario(db, "admin", "admin123", "Administrador", PERFIL_ADMIN)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT NOT NULL UNIQUE COLLATE NOCASE,
                senha_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                funcao TEXT NOT NULL DEFAULT '',
                perfil TEXT NOT NULL DEFAULT 'colaborador'
            )"""
        )
        db.execSQL(
            """CREATE TABLE estoque (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                equipamento TEXT NOT NULL,
                tamanho TEXT NOT NULL,
                quantidade INTEGER NOT NULL CHECK (quantidade >= 0),
                UNIQUE (equipamento, tamanho)
            )"""
        )
        db.execSQL(
            """CREATE TABLE retiradas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT NOT NULL,
                equipamento TEXT NOT NULL,
                tamanho TEXT NOT NULL,
                data_hora INTEGER NOT NULL,
                assinatura BLOB
            )"""
        )

        // usuário normal e admin
        garantirUsuariosPadrao(db)

        // estoque inicial
        val inicial = listOf(
            Triple(BOTA, "38", 4), Triple(BOTA, "40", 7), Triple(BOTA, "42", 0), Triple(BOTA, "44", 2),
            Triple(CAPACETE, "P", 12), Triple(CAPACETE, "M", 8), Triple(CAPACETE, "G", 1),
            Triple(CAPACETE, "GG", 0), Triple(CAPACETE, "XG", 0),
            Triple(LUVA, "P", 6), Triple(LUVA, "M", 10), Triple(LUVA, "G", 3), Triple(LUVA, "GG", 0),
            Triple(OCULOS, "Único", 20),
            Triple(PROTETOR, "Único", 35)
        )
        inicial.forEach { (equip, tam, qtd) ->
            db.insert("estoque", null, ContentValues().apply {
                put("equipamento", equip)
                put("tamanho", tam)
                put("quantidade", qtd)
            })
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 3) {
            // v3: guarda função e perfil do colaborador
            db.execSQL("ALTER TABLE usuarios ADD COLUMN funcao TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE usuarios ADD COLUMN perfil TEXT NOT NULL DEFAULT 'colaborador'")
            db.execSQL("UPDATE usuarios SET perfil = 'admin', funcao = 'Administrador' WHERE usuario = 'admin' COLLATE NOCASE")
        }
        garantirUsuariosPadrao(db)
    }

    // ---------- login ----------

    fun autenticar(usuario: String, senha: String): Boolean {
        readableDatabase.rawQuery(
            "SELECT senha_hash, salt FROM usuarios WHERE usuario = ? COLLATE NOCASE", arrayOf(usuario)
        ).use { c ->
            if (!c.moveToFirst()) return false
            return hash(senha, c.getString(1)) == c.getString(0)
        }
    }

    fun ehAdmin(usuario: String): Boolean {
        readableDatabase.rawQuery(
            "SELECT perfil FROM usuarios WHERE usuario = ? COLLATE NOCASE", arrayOf(usuario)
        ).use { c ->
            return c.moveToFirst() && c.getString(0) == PERFIL_ADMIN
        }
    }

    // ---------- colaboradores ----------

    fun cadastrarColaborador(usuario: String, senha: String, funcao: String): ResultadoCadastro {
        val db = writableDatabase

        db.rawQuery(
            "SELECT 1 FROM usuarios WHERE usuario = ? COLLATE NOCASE", arrayOf(usuario)
        ).use { c ->
            if (c.moveToFirst()) return ResultadoCadastro.JA_EXISTE
        }

        val salt = novoSalt()
        val id = db.insert("usuarios", null, ContentValues().apply {
            put("usuario", usuario)
            put("salt", salt)
            put("senha_hash", hash(senha, salt))
            put("funcao", funcao)
            put("perfil", PERFIL_COLABORADOR)
        })
        return if (id == -1L) ResultadoCadastro.ERRO else ResultadoCadastro.OK
    }

    // ---------- estoque ----------

    fun equipamentosCadastrados(): List<String> {
        val lista = mutableListOf<String>()
        readableDatabase.rawQuery(
            "SELECT equipamento FROM estoque GROUP BY equipamento ORDER BY MIN(id)", null
        ).use { c ->
            while (c.moveToNext()) lista.add(c.getString(0))
        }
        return lista
    }

    fun estoqueDe(equipamento: String): LinkedHashMap<String, Int> {
        val mapa = LinkedHashMap<String, Int>()
        readableDatabase.rawQuery(
            "SELECT tamanho, quantidade FROM estoque WHERE equipamento = ? ORDER BY id",
            arrayOf(equipamento)
        ).use { c ->
            while (c.moveToNext()) mapa[c.getString(0)] = c.getInt(1)
        }
        return mapa
    }

    fun adicionarEstoque(equipamento: String, tamanho: String, quantidade: Int): Boolean {
        if (quantidade <= 0) return false
        val db = writableDatabase
        db.beginTransaction()
        try {
            val nome = db.rawQuery(
                "SELECT equipamento FROM estoque WHERE equipamento = ? COLLATE NOCASE LIMIT 1",
                arrayOf(equipamento)
            ).use { c -> if (c.moveToFirst()) c.getString(0) else equipamento }

            val soma = db.compileStatement(
                "UPDATE estoque SET quantidade = quantidade + ? WHERE equipamento = ? AND tamanho = ?"
            )
            soma.bindLong(1, quantidade.toLong())
            soma.bindString(2, nome)
            soma.bindString(3, tamanho)

            if (soma.executeUpdateDelete() == 0) {
                db.insertOrThrow("estoque", null, ContentValues().apply {
                    put("equipamento", nome)
                    put("tamanho", tamanho)
                    put("quantidade", quantidade)
                })
            }
            db.setTransactionSuccessful()
            return true
        } finally {
            db.endTransaction()
        }
    }

    // ---------- retiradas ----------

    fun registrarRetirada(
        usuario: String,
        equipamento: String,
        tamanho: String,
        assinatura: ByteArray
    ): Boolean {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val baixa = db.compileStatement(
                "UPDATE estoque SET quantidade = quantidade - 1 " +
                        "WHERE equipamento = ? AND tamanho = ? AND quantidade > 0"
            )
            baixa.bindString(1, equipamento)
            baixa.bindString(2, tamanho)
            if (baixa.executeUpdateDelete() == 0) return false   // finally encerra a transação

            db.insertOrThrow("retiradas", null, ContentValues().apply {
                put("usuario", usuario)
                put("equipamento", equipamento)
                put("tamanho", tamanho)
                put("data_hora", System.currentTimeMillis())
                put("assinatura", assinatura)
            })
            db.setTransactionSuccessful()
            return true
        } finally {
            db.endTransaction()
        }
    }

    fun listarRetiradas(usuario: String): List<Retirada> {
        val formato = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
        val lista = mutableListOf<Retirada>()
        readableDatabase.rawQuery(
            "SELECT id, usuario, equipamento, tamanho, data_hora, assinatura " +
                    "FROM retiradas WHERE usuario = ? COLLATE NOCASE ORDER BY data_hora DESC",
            arrayOf(usuario)
        ).use { c ->
            while (c.moveToNext()) {
                lista.add(
                    Retirada(
                        id = c.getInt(0),
                        usuario = c.getString(1),
                        equipamento = c.getString(2),
                        tamanho = c.getString(3),
                        dataHora = formato.format(Date(c.getLong(4))),
                        assinatura = c.getBlob(5)
                    )
                )
            }
        }
        return lista
    }
}