package com.example.epi_app

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Historico : AppCompatActivity() {

    private lateinit var llHistorico: LinearLayout
    private lateinit var tvVazio: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // sem login, volta pra tela de login
        if (Sessao.usuario.isEmpty()) {
            startActivity(Intent(this, Login::class.java))
            finish()
            return
        }

        enableEdgeToEdge()
        setContentView(R.layout.activity_historico)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        llHistorico = findViewById(R.id.llHistorico)
        tvVazio = findViewById(R.id.tvVazio)

        findViewById<Button>(R.id.button2).setOnClickListener {   // MENU
            startActivity(Intent(this, menu::class.java))
            finish()
        }
        findViewById<Button>(R.id.button3).setOnClickListener {   // SAIR
            finishAffinity()
        }

        carregarHistorico()
    }

    private fun carregarHistorico() {
        val lista = Db.get(this).listarRetiradas(Sessao.usuario)   // só as do usuário logado

        llHistorico.removeAllViews()
        tvVazio.visibility = if (lista.isEmpty()) View.VISIBLE else View.GONE

        val inflater = LayoutInflater.from(this)
        lista.forEach { r ->
            val item = inflater.inflate(R.layout.item_retirada, llHistorico, false)
            item.findViewById<TextView>(R.id.tvEquip).text = r.equipamento
            item.findViewById<TextView>(R.id.tvDetalhes).text = "Tamanho ${r.tamanho} • ${r.usuario}"
            item.findViewById<TextView>(R.id.tvData).text = r.dataHora
            r.assinatura?.let { bytes ->
                item.findViewById<ImageView>(R.id.ivAssinatura)
                    .setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
            }
            llHistorico.addView(item)
        }
    }
}