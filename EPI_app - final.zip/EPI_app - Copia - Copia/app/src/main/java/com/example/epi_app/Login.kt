package com.example.epi_app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Login : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val db = Db.get(this)
        val etUser = findViewById<EditText>(R.id.iduser)
        val etSenha = findViewById<EditText>(R.id.idpassword)
        val btEntrar = findViewById<Button>(R.id.btenter)
        val btSair = findViewById<Button>(R.id.btexit)

        btEntrar.setOnClickListener {
            val user = etUser.text.toString().trim()
            val senha = etSenha.text.toString()

            if (user.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Preencha usuário e senha.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val autenticado = try {
                db.autenticar(user, senha)
            } catch (e: Exception) {
                Toast.makeText(this, "Erro ao acessar o banco: ${e.message}", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (!autenticado) {
                Toast.makeText(this, "Usuário ou senha incorretos.", Toast.LENGTH_SHORT).show()
                etSenha.text.clear()
                return@setOnClickListener
            }

            Sessao.usuario = user

            val destino: Class<*> =
                if (db.ehAdmin(user)) Menu_Admin::class.java else menu::class.java

            try {
                val intent = Intent(this, destino).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "Não foi possível abrir o menu: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        btSair.setOnClickListener { finishAffinity() }
    }
}