package com.example.epi_app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class Cadastro_Equipamento : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = Db.get(this)

        // só o admin pode cadastrar equipamento
        if (!db.ehAdmin(Sessao.usuario)) {
            startActivity(Intent(this, Login::class.java))
            finish()
            return
        }

        enableEdgeToEdge()
        setContentView(R.layout.activity_cadastro_equipamento)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val nomes: Map<Int, String> = mapOf(
            R.id.checkBox to Db.BOTA,
            R.id.checkBox2 to Db.CAPACETE,
            R.id.checkBox3 to Db.LUVA,
            R.id.checkBox4 to Db.OCULOS,
            R.id.checkBox6 to Db.PROTETOR
        )
        val cbNovo = findViewById<CheckBox>(R.id.checkBox5)
        val todos: List<CheckBox> = nomes.keys.map { findViewById<CheckBox>(it) } + cbNovo

        val cardNovo = findViewById<View>(R.id.cardNovo)
        val etNovo = findViewById<EditText>(R.id.editTextText4)
        val cgTamanho = findViewById<ChipGroup>(R.id.cgTamanhoNovo)
        val etQtd = findViewById<EditText>(R.id.etQuantidade)

        todos.forEach { cb ->
            cb.setOnCheckedChangeListener { _, marcado ->
                if (marcado) {
                    todos.filter { it !== cb && it.isChecked }.forEach { it.isChecked = false }
                }
                cardNovo.visibility = if (cbNovo.isChecked) View.VISIBLE else View.GONE
            }
        }

        // CADASTRAR
        findViewById<Button>(R.id.btnCadastrarEquip).setOnClickListener {
            val equipamento: String? = if (cbNovo.isChecked) {
                etNovo.text.toString().trim()
            } else {
                todos.firstOrNull { it.isChecked }?.let { nomes[it.id] }
            }

            if (equipamento.isNullOrEmpty()) {
                val msg = if (cbNovo.isChecked) "Digite o nome do novo equipamento."
                else "Selecione um equipamento."
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val chipId = cgTamanho.checkedChipId
            if (chipId == View.NO_ID) {
                Toast.makeText(this, "Selecione o tamanho.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val tamanho = findViewById<Chip>(chipId).text.toString()

            val quantidade = etQtd.text.toString().trim().toIntOrNull()
            if (quantidade == null || quantidade <= 0) {
                Toast.makeText(this, "Informe uma quantidade maior que zero.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val ok = try {
                db.adicionarEstoque(equipamento, tamanho, quantidade)
            } catch (e: Exception) {
                Toast.makeText(this, "Erro ao salvar: ${e.message}", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (ok) {
                Toast.makeText(
                    this,
                    "Estoque atualizado: $equipamento ($tamanho) +$quantidade",
                    Toast.LENGTH_LONG
                ).show()
                startActivity(Intent(this, Menu_Admin::class.java))
                finish()
            } else {
                Toast.makeText(this, "Não foi possível cadastrar. Tente novamente.", Toast.LENGTH_LONG).show()
            }
        }

        findViewById<Button>(R.id.btnMenuAdmin).setOnClickListener {
            startActivity(Intent(this, Menu_Admin::class.java))
            finish()
        }
    }
}