package com.example.epi_app

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.NestedScrollView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class menu : AppCompatActivity() {

    private lateinit var db: Db
    private lateinit var checkboxes: List<CheckBox>
    private lateinit var cgTamanho: ChipGroup

    private lateinit var btnAssinar: TextView
    private lateinit var cardAssinar: View
    private lateinit var cardAssinatura: View

    private lateinit var signatureView: SignatureView
    private lateinit var tvAssinaturaHint: TextView

    private val nomes: MutableMap<Int, String> = mutableMapOf(
        R.id.cbboot to Db.BOTA,
        R.id.cbcap to Db.CAPACETE,
        R.id.cbgloves to Db.LUVA,
        R.id.cbglasses to Db.OCULOS,
        R.id.cbearprotector to Db.PROTETOR
    )

    private var equipamentoAtual: CheckBox? = null
    private var tamanhoAtual: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Sessao.usuario.isEmpty()) {
            startActivity(Intent(this, Login::class.java))
            finish()
            return
        }

        enableEdgeToEdge()
        setContentView(R.layout.activity_menu)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        db = Db.get(this)

        val fixos: List<CheckBox> = listOf(
            findViewById(R.id.cbboot),
            findViewById(R.id.cbcap),
            findViewById(R.id.cbgloves),
            findViewById(R.id.cbglasses),
            findViewById(R.id.cbearprotector)
        )
        checkboxes = fixos + criarCheckboxesNovos()
        cgTamanho = findViewById(R.id.cgTamanho)
        btnAssinar = findViewById(R.id.btnAssinar)
        cardAssinar = findViewById(R.id.cardAssinar)
        cardAssinatura = findViewById(R.id.cardAssinatura)
        signatureView = findViewById(R.id.signatureView)
        tvAssinaturaHint = findViewById(R.id.tvAssinaturaHint)

        definirBotaoAtivo(false)

        checkboxes.forEach { cb ->
            cb.setOnCheckedChangeListener { _, marcado ->
                if (marcado) {
                    checkboxes.filter { it !== cb && it.isChecked }.forEach { it.isChecked = false }
                    equipamentoAtual = cb
                    montarChips(cb.id)
                } else if (equipamentoAtual === cb) {
                    equipamentoAtual = null
                    montarChips(null)
                }
            }
        }

        configurarAssinatura()

        btnAssinar.setOnClickListener { confirmarRetirada() }

        findViewById<TextView>(R.id.bthistorico).setOnClickListener {
            startActivity(Intent(this, Historico::class.java))
        }
    }

    private fun criarCheckboxesNovos(): List<CheckBox> {
        val container = findViewById<LinearLayout>(R.id.scrollEquip)
        val densidade = resources.displayMetrics.density
        val novos = mutableListOf<CheckBox>()

        db.equipamentosCadastrados()
            .filter { nome -> nome !in nomes.values }
            .forEach { nome ->
                // linha separadora, igual à que existe entre os itens do layout
                container.addView(View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        (1 * densidade).toInt()
                    )
                    setBackgroundColor(Color.parseColor("#E3E9DE"))
                })

                val cb = CheckBox(this).apply {
                    id = View.generateViewId()
                    text = nome
                    textSize = 16f
                    setTextColor(Color.parseColor("#1F2A24"))
                    buttonTintList = ColorStateList.valueOf(Color.parseColor("#3E7B52"))
                    minHeight = (50 * densidade).toInt()
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }
                container.addView(cb)

                nomes[cb.id] = nome      // liga o checkbox ao nome do equipamento no banco
                novos.add(cb)
            }
        return novos
    }

    private fun definirBotaoAtivo(ativo: Boolean) {
        btnAssinar.isEnabled = ativo
        cardAssinar.alpha = if (ativo) 1f else 0.45f
        if (ativo) {
            if (cardAssinatura.visibility != View.VISIBLE) {
                cardAssinatura.visibility = View.VISIBLE
                val scroll = findViewById<NestedScrollView>(R.id.scrollMain)
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        } else {
            cardAssinatura.visibility = View.GONE
            limparAssinatura()
        }
    }

    private fun configurarAssinatura() {
        signatureView.setOnTouchListener { v, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                v.parent?.requestDisallowInterceptTouchEvent(true)
                tvAssinaturaHint.visibility = View.GONE
            }
            false
        }

        findViewById<TextView>(R.id.btnLimparAssinatura).setOnClickListener {
            limparAssinatura()
        }
    }

    private fun limparAssinatura() {
        signatureView.limpar()
        tvAssinaturaHint.visibility = View.VISIBLE
    }

    private fun montarChips(checkboxId: Int?) {
        cgTamanho.removeAllViews()
        tamanhoAtual = null
        definirBotaoAtivo(false)

        val equipamento = checkboxId?.let { nomes[it] } ?: return
        val tamanhos = db.estoqueDe(equipamento)

        val fundo = ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf(-android.R.attr.state_enabled),
                intArrayOf()
            ),
            intArrayOf(Color.parseColor("#BCD9C4"), Color.parseColor("#E8ECE4"), Color.WHITE)
        )

        tamanhos.forEach { (tamanho, qtd) ->
            val chip = Chip(this).apply {
                text = "$tamanho ($qtd)"
                tag = tamanho
                isCheckable = true
                isCheckedIconVisible = false
                chipBackgroundColor = fundo
                chipStrokeColor = ColorStateList.valueOf(Color.parseColor("#1F2A24"))
                chipStrokeWidth = 2f * resources.displayMetrics.density
                setTextColor(Color.parseColor(if (qtd > 0) "#1F2A24" else "#8A9A8F"))
                setOnCheckedChangeListener { _, marcado ->
                    tamanhoAtual = if (marcado) tamanho else null
                    definirBotaoAtivo(marcado && qtd > 0)
                    if (marcado && qtd == 0) {
                        Toast.makeText(
                            this@menu,
                            "$equipamento tamanho $tamanho está em falta.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
            cgTamanho.addView(chip)
        }
    }

    private fun confirmarRetirada() {
        val cb = equipamentoAtual ?: return
        val equip = nomes[cb.id] ?: return
        val tam = tamanhoAtual ?: return

        if (signatureView.estaVazia()) {
            tvAssinaturaHint.visibility = View.VISIBLE
            Toast.makeText(this, "Faça a assinatura antes de confirmar.", Toast.LENGTH_SHORT).show()
            return
        }

        val png = signatureView.toPng()

        autenticar {
            registrar(equip, tam, png)
        }
    }

    private fun autenticar(aoConfirmar: () -> Unit) {
        val permitido = BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL

        if (BiometricManager.from(this).canAuthenticate(permitido) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(
                this,
                "Cadastre uma biometria ou um bloqueio de tela no celular para confirmar a retirada.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    aoConfirmar()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON
                    ) {
                        Toast.makeText(this@menu, "Autenticação não concluída: $errString", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Confirme sua identidade")
            .setSubtitle("Usuário: ${Sessao.usuario}")
            .setAllowedAuthenticators(permitido)
            .build()

        prompt.authenticate(info)
    }

    private fun registrar(equipamento: String, tamanho: String, assinaturaPng: ByteArray) {
        val ok = db.registrarRetirada(Sessao.usuario, equipamento, tamanho, assinaturaPng)
        if (ok) {
            Toast.makeText(this, "Retirada registrada: $equipamento ($tamanho)", Toast.LENGTH_LONG).show()
            limparAssinatura()
        } else {
            Toast.makeText(this, "Tamanho $tamanho em falta.", Toast.LENGTH_LONG).show()
        }
        montarChips(equipamentoAtual?.id)
    }
}